package com.netim.app.engine;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;

/** Tum soru ureticilerinin kaydi. Sorular cihazda, kural ve hesapla uretilir; internet gerekmez. */
public final class Engine {
    public static final String MAT = "Matematik";
    public static final String TUR = "Türkçe";

    private interface Fn {
        Question apply(Random r, Gen g);
    }

    private static final class G implements Gen {
        final String subject;
        final String topic;
        final Fn fn;

        G(String subject, String topic, Fn fn) {
            this.subject = subject;
            this.topic = topic;
            this.fn = fn;
        }

        @Override
        public String subject() {
            return subject;
        }

        @Override
        public String topic() {
            return topic;
        }

        @Override
        public Question make(Random r) {
            return fn.apply(r, this);
        }
    }

    private static final List<Gen> ALL = new ArrayList<>();

    private Engine() {
    }

    public static List<Gen> all() {
        return ALL;
    }

    public static List<Gen> bySubject(String subject) {
        List<Gen> out = new ArrayList<>();
        for (Gen g : ALL) if (g.subject().equals(subject)) out.add(g);
        return out;
    }

    public static List<String> subjects() {
        return Arrays.asList(MAT, TUR);
    }

    /** Hata olursa baska bir deneme yapar; yanlis soru gostermemek icin dogrulama hatasi olan soru atilir. */
    public static Question next(Gen g, Random r) {
        for (int i = 0; i < 8; i++) {
            try {
                return g.make(r);
            } catch (IllegalStateException e) {
                // dogrulama basarisiz: yeniden uret
            }
        }
        throw new IllegalStateException("Soru uretilemedi: " + g.topic());
    }

    private static void add(String s, String t, Fn fn) {
        ALL.add(new G(s, t, fn));
    }

    static {
        // ---------- MATEMATIK ----------
        add(MAT, "İşlem önceliği", (r, g) -> {
            int a = Qb.range(r, 2, 30), b = Qb.range(r, 2, 9), c = Qb.range(r, 2, 9), e = Qb.range(r, 2, 6), k = Qb.range(r, 2, 9);
            int d = e * k;
            long ans = a + (long) b * c - k;
            String text = a + " + " + b + " × " + c + " − " + d + " ÷ " + e + " işleminin sonucu kaçtır?";
            long w1 = (long) (a + b) * c - k;
            long w2 = a + (long) b * c - d;
            String sol = "Önce çarpma ve bölme yapılır: " + b + " × " + c + " = " + (b * c) + " ve " + d + " ÷ " + e + " = " + k
                    + ". Sonra soldan sağa toplama ve çıkarma yapılır: " + a + " + " + (b * c) + " − " + k + " = " + ans + ".";
            return Qb.build(g, text, String.valueOf(ans), Qb.numericPool(0, ans, w1, w2), sol, r);
        });

        add(MAT, "EBOB - EKOK", (r, g) -> {
            int d = Qb.range(r, 2, 12), m = Qb.range(r, 2, 9), n = Qb.range(r, 2, 9);
            while (n == m || Frac.gcd(m, n) != 1) n = Qb.range(r, 2, 9);
            long a = (long) d * m, b = (long) d * n;
            boolean ebob = r.nextBoolean();
            long bg = 0;
            for (long i = 1; i <= Math.min(a, b); i++) if (a % i == 0 && b % i == 0) bg = i;
            long bl = Math.max(a, b);
            while (bl % a != 0 || bl % b != 0) bl += Math.max(a, b);
            long ans = ebob ? bg : bl;
            Qb.check(bg == d && bl == (long) d * m * n, "ebob/ekok");
            String text = a + " ve " + b + " sayılarının " + (ebob ? "EBOB'u" : "EKOK'u") + " kaçtır?";
            String sol = a + " = " + d + " × " + m + " ve " + b + " = " + d + " × " + n + " olarak yazılır; " + m + " ile " + n
                    + " aralarında asaldır. EBOB = " + bg + ", EKOK = " + d + " × " + m + " × " + n + " = " + bl + ".";
            return Qb.build(g, text, String.valueOf(ans), Qb.numericPool(1, ans, ebob ? bl : bg, a - b > 0 ? a - b : b - a, (long) d * m), sol, r);
        });

        add(MAT, "Kesirlerle işlemler", (r, g) -> {
            int[] ds = {2, 3, 4, 5, 6, 8, 10, 12};
            int b, d, a, c;
            boolean add = r.nextBoolean();
            do {
                b = ds[r.nextInt(ds.length)];
                d = ds[r.nextInt(ds.length)];
                a = Qb.range(r, 1, b - 1);
                c = Qb.range(r, 1, d - 1);
            } while (!add && (long) a * d <= (long) c * b);
            long num = add ? (long) a * d + (long) c * b : (long) a * d - (long) c * b;
            Frac res = new Frac(num, (long) b * d);
            String text = a + "/" + b + (add ? " + " : " − ") + c + "/" + d + " işleminin sonucu kaçtır? (Sade kesir olarak)";
            Frac w1 = new Frac(add ? a + c : a - c, add ? b + d : b + d);
            String sol = "Paydalar eşitlenir: (" + a + "×" + d + (add ? " + " : " − ") + c + "×" + b + ") / (" + b + "×" + d + ") = " + num + "/" + ((long) b * d)
                    + " olur. Sadeleştirince " + res + " bulunur.";
            return Qb.build(g, text, res.toString(), Qb.fracPool(res, w1, new Frac(res.n + 1, res.d), new Frac(res.n, res.d + 1)), sol, r);
        });

        add(MAT, "Yüzde problemleri", (r, g) -> {
            if (r.nextBoolean()) {
                int x = 20 * Qb.range(r, 1, 15);
                int[] ps = {5, 10, 15, 20, 25, 30, 40, 50, 60, 75};
                int p = Qb.pick(r, new Integer[]{5, 10, 15, 20, 25, 30, 40, 50, 60, 75});
                Qb.check((long) x * p % 100 == 0, "yuzde tam deger");
                long ans = (long) x * p / 100;
                String text = x + " sayısının yüzde " + p + " kadarı kaçtır?";
                String sol = x + " × " + p + " / 100 = " + ans + ".";
                return Qb.build(g, text, String.valueOf(ans), Qb.numericPool(0, ans, x - ans, ans * 2, (long) x * p / 10), sol, r);
            } else {
                int price = 20 * Qb.range(r, 2, 30);
                int p = Qb.pick(r, new Integer[]{10, 20, 25, 30, 40, 50});
                long disc = (long) price * p / 100;
                Qb.check((long) price * p % 100 == 0, "indirim tam deger");
                long ans = price - disc;
                String text = price + " TL olan bir ürüne yüzde " + p + " indirim yapılırsa yeni fiyatı kaç TL olur?";
                String sol = "İndirim miktarı " + price + " × " + p + " / 100 = " + disc + " TL. Yeni fiyat " + price + " − " + disc + " = " + ans + " TL.";
                return Qb.build(g, text, String.valueOf(ans), Qb.numericPool(0, ans, disc, price - p, price + disc), sol, r);
            }
        });

        add(MAT, "Oran - orantı", (r, g) -> {
            String[][] items = {{"kg", "elma"}, {"kg", "domates"}, {"kg", "peynir"}, {"m", "kumaş"}, {"kg", "üzüm"}, {"kg", "şeker"}};
            String[] it = Qb.pick(r, items);
            int k1 = Qb.range(r, 2, 9), k2 = Qb.range(r, 2, 12), u = Qb.range(r, 2, 20);
            while (k2 == k1) k2 = Qb.range(r, 2, 12);
            long c1 = (long) k1 * u, ans = (long) k2 * u;
            String text = k1 + " " + it[0] + " " + it[1] + " " + c1 + " TL ise " + k2 + " " + it[0] + " " + it[1] + " kaç TL'dir?";
            String sol = "1 " + it[0] + " " + it[1] + " " + c1 + " ÷ " + k1 + " = " + u + " TL'dir. " + k2 + " " + it[0] + " " + it[1] + " = " + k2 + " × " + u + " = " + ans + " TL.";
            return Qb.build(g, text, String.valueOf(ans), Qb.numericPool(1, ans, c1 + (k2 - k1), (long) u * (k2 - 1), c1 * k2 / Math.max(1, k1) + 1, (long) (k2 - k1) * u + c1 / 2), sol, r);
        });

        add(MAT, "Birinci dereceden denklem", (r, g) -> {
            int x = Qb.range(r, -9, 12), a = Qb.range(r, 2, 9), b = Qb.range(r, -15, 15);
            if (b == 0) b = 7;
            long c = (long) a * x + b;
            String text = a + "x " + (b > 0 ? "+ " : "− ") + Math.abs(b) + " = " + c + " denkleminde x kaçtır?";
            String sol = a + "x = " + c + (b > 0 ? " − " : " + ") + Math.abs(b) + " = " + (c - b) + ". x = " + (c - b) + " ÷ " + a + " = " + x + ".";
            return Qb.build(g, text, String.valueOf(x), Qb.numericPool(-1000, x, -x, c - b, (c + b) % a == 0 ? (c + b) / a : x + 2, x + 1, x - 1), sol, r);
        });

        add(MAT, "Üslü sayılar", (r, g) -> {
            int type = r.nextInt(3);
            int base = Qb.pick(r, new Integer[]{2, 3, 5});
            if (type == 0) {
                int maxE = base == 2 ? 6 : base == 3 ? 4 : 3;
                int m = Qb.range(r, 2, maxE), n = Qb.range(r, 2, maxE);
                long ans = Qb.pow(base, m + n);
                String text = base + Qb.sup(m) + " × " + base + Qb.sup(n) + " işleminin sonucu kaçtır?";
                String sol = "Tabanlar eşit olduğundan üsler toplanır: " + base + Qb.sup(m + n) + " = " + ans + ".";
                return Qb.build(g, text, String.valueOf(ans), Qb.numericPool(1, ans, Qb.pow(base, m * n), Qb.pow(base, m) + Qb.pow(base, n), Qb.pow(base, m) * n), sol, r);
            } else if (type == 1) {
                int maxE = base == 2 ? 9 : base == 3 ? 6 : 4;
                int n = Qb.range(r, 1, maxE - 1), m = Qb.range(r, n + 1, maxE);
                long ans = Qb.pow(base, m - n);
                String text = base + Qb.sup(m) + " ÷ " + base + Qb.sup(n) + " işleminin sonucu kaçtır?";
                String sol = "Tabanlar eşit olduğundan üsler çıkarılır: " + base + Qb.sup(m - n) + " = " + ans + ".";
                return Qb.build(g, text, String.valueOf(ans), Qb.numericPool(1, ans, Qb.pow(base, m) - Qb.pow(base, n), Qb.pow(base, m + n), Qb.pow(base, m) / Math.max(1, n)), sol, r);
            } else {
                int b2 = Qb.pick(r, new Integer[]{2, 3});
                int m = Qb.range(r, 2, 3), n = Qb.range(r, 2, 3);
                long ans = Qb.pow(b2, m * n);
                String text = "(" + b2 + Qb.sup(m) + ")" + Qb.sup(n) + " işleminin sonucu kaçtır?";
                String sol = "Üssün üssünde üsler çarpılır: " + b2 + Qb.sup(m * n) + " = " + ans + ".";
                return Qb.build(g, text, String.valueOf(ans), Qb.numericPool(1, ans, Qb.pow(b2, m + n), Qb.pow(b2, m) * n, Qb.pow(b2, m) + Qb.pow(b2, n)), sol, r);
            }
        });

        add(MAT, "Karekök", (r, g) -> {
            int p = Qb.range(r, 2, 15), q = Qb.range(r, 2, 15);
            int type = r.nextInt(3);
            if (type == 1 && p <= q) {
                int t = p;
                p = q;
                q = t;
                if (p == q) p++;
            }
            String text;
            long ans;
            String sol;
            if (type == 0) {
                ans = p + q;
                text = "√" + (p * p) + " + √" + (q * q) + " işleminin sonucu kaçtır?";
                sol = "√" + (p * p) + " = " + p + " ve √" + (q * q) + " = " + q + ". Toplam " + ans + ".";
            } else if (type == 1) {
                ans = p - q;
                text = "√" + (p * p) + " − √" + (q * q) + " işleminin sonucu kaçtır?";
                sol = "√" + (p * p) + " = " + p + " ve √" + (q * q) + " = " + q + ". Fark " + ans + ".";
            } else {
                int s = Qb.range(r, 2, 9), t2 = Qb.range(r, 2, 9);
                ans = (long) s * t2;
                text = "√" + (s * s) + " × √" + (t2 * t2) + " işleminin sonucu kaçtır?";
                sol = "√" + (s * s) + " = " + s + " ve √" + (t2 * t2) + " = " + t2 + ". Çarpım " + ans + ".";
                return Qb.build(g, text, String.valueOf(ans), Qb.numericPool(1, ans, s + t2, (long) s * s + t2 * t2, ans + s), sol, r);
            }
            return Qb.build(g, text, String.valueOf(ans), Qb.numericPool(0, ans, (long) p * q, ans + 1, ans - 1, (long) p * p + q * q), sol, r);
        });

        add(MAT, "Aritmetik ortalama", (r, g) -> {
            int[] v = new int[4];
            int sum = 0;
            for (int i = 0; i < 4; i++) {
                v[i] = Qb.range(r, 5, 60);
                sum += v[i];
            }
            int f = Qb.range(r, 5, 60);
            while ((sum + f) % 5 != 0) f = f == 60 ? 5 : f + 1;
            int total = sum + f;
            int mean = total / 5;
            Qb.check(total % 5 == 0, "ortalama");
            if (r.nextBoolean()) {
                text5:
                {
                    String list = v[0] + ", " + v[1] + ", " + v[2] + ", " + v[3] + ", " + f;
                    String text = list + " sayılarının aritmetik ortalaması kaçtır?";
                    String sol = "Sayıların toplamı " + total + ". Ortalama = " + total + " ÷ 5 = " + mean + ".";
                    int[] sorted = {v[0], v[1], v[2], v[3], f};
                    Arrays.sort(sorted);
                    return Qb.build(g, text, String.valueOf(mean), Qb.numericPool(1, mean, sorted[2], total, sorted[4] - sorted[0], mean + 1), sol, r);
                }
            }
            String text = "Beş sayının aritmetik ortalaması " + mean + "'dir. Bu sayılardan dördü " + v[0] + ", " + v[1] + ", " + v[2] + " ve " + v[3]
                    + " ise beşinci sayı kaçtır?";
            String sol = "Beş sayının toplamı " + mean + " × 5 = " + total + ". Bilinen dört sayının toplamı " + sum + ". Beşinci sayı " + total + " − " + sum + " = " + f + ".";
            return Qb.build(g, text, String.valueOf(f), Qb.numericPool(1, f, mean, total, sum, f + 5), sol, r);
        });

        add(MAT, "Pisagor teoremi", (r, g) -> {
            int[][] tri = {{3, 4, 5}, {5, 12, 13}, {8, 15, 17}, {7, 24, 25}};
            int[] t = Qb.pick(r, tri);
            int k = t[0] == 3 ? Qb.range(r, 1, 6) : Qb.range(r, 1, 3);
            int a = t[0] * k, b = t[1] * k, c = t[2] * k;
            Qb.check((long) a * a + (long) b * b == (long) c * c, "pisagor");
            if (r.nextBoolean()) {
                String text = "Dik kenar uzunlukları " + a + " cm ve " + b + " cm olan bir dik üçgenin hipotenüsü kaç cm'dir?";
                String sol = "Pisagor: " + a + "² + " + b + "² = " + (a * a) + " + " + (b * b) + " = " + (c * c) + ". Hipotenüs √" + (c * c) + " = " + c + " cm.";
                return Qb.build(g, text, String.valueOf(c), Qb.numericPool(1, c, a + b, b - a > 0 ? b - a : a - b, c + 1), sol, r);
            }
            String text = "Hipotenüsü " + c + " cm, bir dik kenarı " + a + " cm olan dik üçgenin diğer dik kenarı kaç cm'dir?";
            String sol = "Pisagor: diğer kenar² = " + c + "² − " + a + "² = " + (c * c) + " − " + (a * a) + " = " + (b * b) + ". Kenar √" + (b * b) + " = " + b + " cm.";
            return Qb.build(g, text, String.valueOf(b), Qb.numericPool(1, b, c - a, c + a, b + 1), sol, r);
        });

        add(MAT, "Alan ve çevre", (r, g) -> {
            int type = r.nextInt(4);
            if (type == 0) {
                int a = Qb.range(r, 3, 15), b = Qb.range(r, 2, 14);
                while (b == a) b = Qb.range(r, 2, 14);
                int p = 2 * (a + b);
                long ans = (long) a * b;
                String text = "Çevresi " + p + " cm olan bir dikdörtgenin bir kenarı " + a + " cm ise alanı kaç cm²'dir?";
                String sol = "Yarım çevre " + (p / 2) + " cm olduğundan diğer kenar " + (p / 2) + " − " + a + " = " + b + " cm. Alan " + a + " × " + b + " = " + ans + " cm².";
                return Qb.build(g, text, String.valueOf(ans), Qb.numericPool(1, ans, (long) a * (a + b), p, a + b, (long) p * a), sol, r);
            } else if (type == 1) {
                int t = Qb.range(r, 4, 20), h = Qb.range(r, 3, 16);
                if ((t * h) % 2 != 0) h++;
                long ans = (long) t * h / 2;
                String text = "Taban uzunluğu " + t + " cm, yüksekliği " + h + " cm olan üçgenin alanı kaç cm²'dir?";
                String sol = "Üçgenin alanı taban × yükseklik ÷ 2 = " + t + " × " + h + " ÷ 2 = " + ans + " cm².";
                return Qb.build(g, text, String.valueOf(ans), Qb.numericPool(1, ans, (long) t * h, t + h, ans + t), sol, r);
            } else if (type == 2) {
                int a = Qb.range(r, 2, 15);
                long ans = (long) a * a;
                String text = "Çevresi " + (4 * a) + " cm olan karenin alanı kaç cm²'dir?";
                String sol = "Karenin bir kenarı " + (4 * a) + " ÷ 4 = " + a + " cm. Alan " + a + " × " + a + " = " + ans + " cm².";
                return Qb.build(g, text, String.valueOf(ans), Qb.numericPool(1, ans, 4L * a, 2L * a, (long) (2 * a) * (2 * a)), sol, r);
            } else {
                int rad = Qb.range(r, 2, 12);
                if (r.nextBoolean()) {
                    long ans = 6L * rad;
                    String text = "π = 3 alınırsa yarıçapı " + rad + " cm olan dairenin çevresi kaç cm'dir?";
                    String sol = "Çevre = 2 × π × r = 2 × 3 × " + rad + " = " + ans + " cm.";
                    return Qb.build(g, text, String.valueOf(ans), Qb.numericPool(1, ans, 3L * rad * rad, 3L * rad, 12L * rad), sol, r);
                }
                long ans = 3L * rad * rad;
                String text = "π = 3 alınırsa yarıçapı " + rad + " cm olan dairenin alanı kaç cm²'dir?";
                String sol = "Alan = π × r² = 3 × " + rad + " × " + rad + " = " + ans + " cm².";
                return Qb.build(g, text, String.valueOf(ans), Qb.numericPool(1, ans, 6L * rad, (long) (3 * rad) * (3 * rad), 3L * rad), sol, r);
            }
        });

        add(MAT, "Hız - yol - zaman", (r, g) -> {
            int type = r.nextInt(3);
            if (type == 0) {
                int v = 10 * Qb.range(r, 4, 12), t = Qb.range(r, 2, 8);
                long ans = (long) v * t;
                String text = "Saatte " + v + " km hızla giden bir araç " + t + " saatte kaç km yol alır?";
                String sol = "Yol = hız × zaman = " + v + " × " + t + " = " + ans + " km.";
                return Qb.build(g, text, String.valueOf(ans), Qb.numericPool(1, ans, v + t, (long) v / t, ans + v), sol, r);
            } else if (type == 1) {
                int v1 = 10 * Qb.range(r, 3, 9), v2 = 10 * Qb.range(r, 3, 9), t = Qb.range(r, 2, 6);
                long d = (long) (v1 + v2) * t;
                String text = "Aralarında " + d + " km olan iki araç aynı anda birbirine doğru hareket ediyor. Hızları saatte " + v1 + " km ve " + v2
                        + " km ise kaç saat sonra karşılaşırlar?";
                String sol = "Birbirine yaklaşma hızı " + v1 + " + " + v2 + " = " + (v1 + v2) + " km/sa. Süre = " + d + " ÷ " + (v1 + v2) + " = " + t + " saat.";
                return Qb.build(g, text, String.valueOf(t), Qb.numericPool(1, t, t + 1, t - 1, 2L * t, t + 2), sol, r);
            }
            int v = 10 * Qb.range(r, 4, 12), t = Qb.range(r, 2, 8);
            long d = (long) v * t;
            String text = d + " km'lik yolu " + t + " saatte alan bir aracın hızı saatte kaç km'dir?";
            String sol = "Hız = yol ÷ zaman = " + d + " ÷ " + t + " = " + v + " km/sa.";
            return Qb.build(g, text, String.valueOf(v), Qb.numericPool(1, v, d - t, d + t, (long) v + 10, (long) v - 10), sol, r);
        });

        // Birlikte calisma: tam sayi sonuc veren (x, y) cifti
        final List<int[]> work = new ArrayList<>();
        for (int x = 2; x <= 60; x++) {
            for (int y = x; y <= 60; y++) {
                if ((x * y) % (x + y) == 0 && (x * y) / (x + y) >= 2) work.add(new int[]{x, y});
            }
        }
        add(MAT, "İş problemleri", (r, g) -> {
            int[] p = work.get(r.nextInt(work.size()));
            String[] names = {"Ali", "Ayşe", "Mehmet", "Zeynep", "Can", "Elif"};
            int i1 = r.nextInt(names.length), i2 = r.nextInt(names.length);
            while (i2 == i1) i2 = r.nextInt(names.length);
            int x = p[0], y = p[1];
            long ans = (long) x * y / (x + y);
            Qb.check(new Frac(1, x).n * 0 == 0 && (long) (x + y) * ans == (long) x * y, "is problemi");
            String text = "Bir işi " + names[i1] + " tek başına " + x + " günde, " + names[i2] + " tek başına " + y + " günde bitirebiliyor. İkisi birlikte çalışırsa işi kaç günde bitirir?";
            String sol = "Bir günde " + names[i1] + " işin 1/" + x + "'ini, " + names[i2] + " işin 1/" + y + "'ini yapar. Birlikte günde " + (y + x) + "/" + ((long) x * y)
                    + " yapar; yani iş " + ans + " günde biter.";
            long avg = (x + y) % 2 == 0 ? (x + y) / 2 : x;
            return Qb.build(g, text, String.valueOf(ans), Qb.numericPool(1, ans, avg, x, y, (long) Math.abs(x - y)), sol, r);
        });

        add(MAT, "Kâr - zarar", (r, g) -> {
            int a = 20 * Qb.range(r, 1, 25);
            int p = Qb.pick(r, new Integer[]{10, 20, 25, 30, 40, 50});
            Qb.check((long) a * p % 100 == 0, "kar tam deger");
            long profit = (long) a * p / 100, sell = a + profit;
            if (r.nextBoolean()) {
                String text = "Alış fiyatı " + a + " TL olan bir mal yüzde " + p + " kârla satılırsa satış fiyatı kaç TL olur?";
                String sol = "Kâr " + a + " × " + p + " / 100 = " + profit + " TL. Satış fiyatı " + a + " + " + profit + " = " + sell + " TL.";
                return Qb.build(g, text, String.valueOf(sell), Qb.numericPool(1, sell, a + p, profit, a - profit), sol, r);
            }
            String text = "Bir mal yüzde " + p + " kârla " + sell + " TL'ye satılıyor. Malın alış fiyatı kaç TL'dir?";
            String sol = "Satış fiyatı alışın %" + (100 + p) + "'üdür. Alış = " + sell + " ÷ " + (100 + p) + " × 100 = " + a + " TL.";
            return Qb.build(g, text, String.valueOf(a), Qb.numericPool(1, a, sell - p, sell - profit, sell + profit), sol, r);
        });

        add(MAT, "Asal sayılar", (r, g) -> {
            if (r.nextBoolean()) {
                int n = Qb.pick(r, new Integer[]{10, 20, 30, 40, 50});
                List<Integer> ps = new ArrayList<>();
                for (int i = 2; i <= n; i++) {
                    boolean prime = true;
                    for (int j = 2; j * j <= i; j++) if (i % j == 0) prime = false;
                    if (prime) ps.add(i);
                }
                int ans = ps.size();
                String text = "1 ile " + n + " arasındaki (" + n + " dahil) asal sayıların sayısı kaçtır?";
                String sol = "Asal sayılar: " + ps.toString().replace("[", "").replace("]", "") + ". Toplam " + ans + " tanedir.";
                return Qb.build(g, text, String.valueOf(ans), Qb.numericPool(1, ans, ans + 1, ans - 1, ans + 2), sol, r);
            }
            int[] primes = {11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 53, 59, 61, 67, 71, 73, 79, 83, 89, 97};
            int p = primes[r.nextInt(primes.length)];
            List<String> wrongs = new ArrayList<>();
            int[] smalls = {3, 7, 9, 11, 13};
            for (int s : smalls) {
                int c = s * Qb.range(r, 3, 9);
                if (c > 11 && c < 100 && c != p && !isPrime(c)) wrongs.add(String.valueOf(c));
            }
            wrongs.add(String.valueOf(9 * 9));
            wrongs.add(String.valueOf(91));
            wrongs.add(String.valueOf(87));
            Qb.check(isPrime(p), "asal");
            String text = "Aşağıdakilerden hangisi asal sayıdır?";
            String sol = p + " sayısı 1 ve kendisinden başka pozitif tam sayıya bölünmez, asaldır. Diğer seçenekler en az bir sayıya daha bölünür.";
            return Qb.build(g, text, String.valueOf(p), wrongs, sol, r);
        });

        add(MAT, "Sayı örüntüleri", (r, g) -> {
            int a1 = Qb.range(r, 1, 20), d = Qb.range(r, 2, 9), n = Qb.range(r, 10, 30);
            long ans = a1 + (long) (n - 1) * d;
            String text = a1 + ", " + (a1 + d) + ", " + (a1 + 2 * d) + ", " + (a1 + 3 * d) + ", ... biçiminde devam eden sayı dizisinin " + n + ". terimi kaçtır?";
            String sol = "Ortak fark " + d + ". n. terim = ilk terim + (n − 1) × fark = " + a1 + " + " + (n - 1) + " × " + d + " = " + ans + ".";
            return Qb.build(g, text, String.valueOf(ans), Qb.numericPool(1, ans, a1 + (long) n * d, a1 + (long) (n - 2) * d, (long) n * d), sol, r);
        });

        add(MAT, "Olasılık", (r, g) -> {
            int red = Qb.range(r, 1, 9), blue = Qb.range(r, 1, 9);
            while (red == blue) blue = Qb.range(r, 1, 9);
            Frac ans = new Frac(red, red + blue);
            String text = "Bir torbada " + red + " kırmızı ve " + blue + " mavi top vardır. Torbadan rastgele çekilen bir topun kırmızı olma olasılığı kaçtır?";
            String sol = "Olasılık = istenen durum sayısı ÷ tüm durum sayısı = " + red + "/" + (red + blue) + (ans.d != red + blue ? " = " + ans : "") + ".";
            return Qb.build(g, text, ans.toString(), Qb.fracPool(ans, new Frac(blue, red + blue), new Frac(red, blue), new Frac(1, red + blue), new Frac(red, red + blue + 1)), sol, r);
        });

        // ---------- TURKCE ----------
        final String[] words = {"su", "ev", "at", "kedi", "masa", "kalem", "kitap", "araba", "kelebek", "çiçek", "okul", "öğretmen", "bilgisayar",
                "televizyon", "çocuk", "anne", "baba", "elma", "armut", "portakal", "pencere", "bahçe", "ağaç", "yağmur", "güneş", "bulut", "deniz",
                "orman", "mutfak", "öğrenci", "kapı", "sandalye", "bisiklet", "uçak", "gemi", "tren", "telefon", "kardeş", "arkadaş", "çanta",
                "defter", "silgi", "kırtasiye", "cumhuriyet", "bayram", "mevsim", "ilkbahar", "sonbahar"};

        add(TUR, "Hece sayısı", (r, g) -> {
            String w = words[r.nextInt(words.length)];
            int ans = vowels(w);
            String text = "\"" + w + "\" sözcüğü kaç heceden oluşur?";
            String sol = "Türkçede her hece tek ünlü (sesli) harf içerir. \"" + w + "\" sözcüğündeki ünlüler: " + vowelList(w) + ". Bu yüzden " + ans + " hecelidir.";
            return Qb.build(g, text, String.valueOf(ans), Qb.numericPool(1, ans, ans + 1, ans - 1, ans + 2), sol, r);
        });

        add(TUR, "Sessiz harf sayısı", (r, g) -> {
            String w = words[r.nextInt(words.length)];
            int ans = w.length() - vowels(w);
            Qb.check(ans >= 1, "sessiz harf");
            String text = "\"" + w + "\" sözcüğünde kaç sessiz (ünsüz) harf vardır?";
            String sol = "\"" + w + "\" sözcüğü " + w.length() + " harflidir. Ünlüler: " + vowelList(w) + " (" + vowels(w) + " tane). Sessiz harf sayısı " + w.length() + " − " + vowels(w) + " = " + ans + ".";
            return Qb.build(g, text, String.valueOf(ans), Qb.numericPool(1, ans, vowels(w), ans + 1, ans - 1), sol, r);
        });

        final String[][] opposites = {{"büyük", "küçük"}, {"uzun", "kısa"}, {"sıcak", "soğuk"}, {"hızlı", "yavaş"}, {"zengin", "fakir"}, {"temiz", "kirli"},
                {"aydınlık", "karanlık"}, {"ileri", "geri"}, {"açık", "kapalı"}, {"tok", "aç"}, {"kalın", "ince"}, {"dar", "geniş"}, {"derin", "sığ"},
                {"eski", "yeni"}, {"gece", "gündüz"}, {"doğru", "yanlış"}, {"güzel", "çirkin"}, {"kolay", "zor"}, {"ucuz", "pahalı"}, {"dolu", "boş"},
                {"yakın", "uzak"}, {"gülmek", "ağlamak"}, {"barış", "savaş"}, {"dost", "düşman"}, {"cesur", "korkak"}, {"cömert", "cimri"},
                {"çalışkan", "tembel"}, {"yüksek", "alçak"}, {"iç", "dış"}, {"gelmek", "gitmek"}};
        add(TUR, "Zıt anlamlı sözcükler", (r, g) -> pairQuestion(g, r, opposites, "zıt (karşıt) anlamlısı", "zıt anlamlıdır"));

        final String[][] synonyms = {{"öğretmen", "muallim"}, {"okul", "mektep"}, {"cevap", "yanıt"}, {"soru", "sual"}, {"ödev", "vazife"}, {"sınav", "imtihan"},
                {"öğrenci", "talebe"}, {"hikâye", "öykü"}, {"yazar", "müellif"}, {"dilek", "temenni"}, {"değer", "kıymet"}, {"zaman", "vakit"},
                {"düşünce", "fikir"}, {"ağaç", "çınar"}};
        // "ağaç-çınar" es anlam degildir (tur-cins); listede yer almasin
        final List<String[]> synList = new ArrayList<>();
        for (String[] s : synonyms) if (!s[0].equals("ağaç")) synList.add(s);
        add(TUR, "Eş anlamlı sözcükler", (r, g) -> pairQuestion(g, r, synList.toArray(new String[0][]), "eş (aynı) anlamlısı", "eş anlamlıdır"));

        final String[] pl = {"kitap", "defter", "masa", "çiçek", "okul", "göz", "araba", "kalem", "sandalye", "bahçe", "kapı", "yıldız", "öğrenci",
                "çocuk", "bulut", "deniz", "orman", "kuş", "ağaç", "elma", "uçak", "gemi", "kedi", "köpek", "balık", "kuzu", "gül", "dağ", "yol", "ev"};
        add(TUR, "Ünlü uyumu (çoğul eki)", (r, g) -> {
            List<String> pool = new ArrayList<>(Arrays.asList(pl));
            java.util.Collections.shuffle(pool, r);
            String[] opts = new String[4];
            String wrongWord = pool.get(0);
            String wrongForm = wrongWord + (backVowel(wrongWord) ? "ler" : "lar");
            String rightForm = wrongWord + (backVowel(wrongWord) ? "lar" : "ler");
            List<String> corrects = new ArrayList<>();
            for (int i = 1; i <= 3; i++) corrects.add(pool.get(i) + (backVowel(pool.get(i)) ? "lar" : "ler"));
            String text = "Aşağıdaki sözcüklerden hangisinde çoğul eki ünlü uyumuna aykırı kullanılmıştır?";
            String sol = "Son ünlüsü kalın (a, ı, o, u) olan sözcük -lar, ince (e, i, ö, ü) olan sözcük -ler alır. \"" + wrongForm + "\" yanlıştır; doğrusu \"" + rightForm + "\" olmalıdır.";
            return Qb.build(g, text, wrongForm, corrects, sol, r);
        });

        final String alphabet = "abcçdefgğhıijklmnoöprsştuüvyz";
        add(TUR, "Alfabetik sıralama", (r, g) -> {
            List<String> pool = new ArrayList<>(Arrays.asList(words));
            java.util.Collections.shuffle(pool, r);
            List<String> four = new ArrayList<>(pool.subList(0, 4));
            boolean first = r.nextBoolean();
            String best = four.get(0);
            for (String w : four) if (first ? cmp(alphabet, w, best) < 0 : cmp(alphabet, w, best) > 0) best = w;
            int count = 0;
            for (String w : four) if (cmp(alphabet, w, best) == 0) count++;
            Qb.check(count == 1, "alfabe tekil");
            List<String> wr = new ArrayList<>(four);
            wr.remove(best);
            String text = "Aşağıdaki sözcüklerden hangisi Türk alfabesindeki sıraya göre " + (first ? "en başta" : "en sonda") + " yer alır?";
            String sol = "Türk alfabesi: a b c ç d e f g ğ h ı i j k l m n o ö p r s ş t u ü v y z. Sözcüklerin ilk harflerine (eşitse sonraki harflere) bakılır; " + (first ? "en başta" : "en sonda") + " yer alan \"" + best + "\" sözcüğüdür.";
            return Qb.build(g, text, best, wr, sol, r);
        });
    }

    // ---- yardimcilar ----
    private static boolean isPrime(int n) {
        if (n < 2) return false;
        for (int j = 2; j * j <= n; j++) if (n % j == 0) return false;
        return true;
    }

    private static boolean isVowel(char c) {
        return "aeıioöuü".indexOf(c) >= 0;
    }

    private static int vowels(String w) {
        int n = 0;
        for (char c : w.toCharArray()) if (isVowel(c)) n++;
        return n;
    }

    private static String vowelList(String w) {
        StringBuilder sb = new StringBuilder();
        for (char c : w.toCharArray()) {
            if (isVowel(c)) {
                if (sb.length() > 0) sb.append(", ");
                sb.append(c);
            }
        }
        return sb.toString();
    }

    private static boolean backVowel(String w) {
        for (int i = w.length() - 1; i >= 0; i--) {
            char c = w.charAt(i);
            if (isVowel(c)) return "aıou".indexOf(c) >= 0;
        }
        return true;
    }

    private static int cmp(String alphabet, String a, String b) {
        int n = Math.min(a.length(), b.length());
        for (int i = 0; i < n; i++) {
            int x = alphabet.indexOf(a.charAt(i)), y = alphabet.indexOf(b.charAt(i));
            if (x != y) return Integer.compare(x, y);
        }
        return Integer.compare(a.length(), b.length());
    }

    private static Question pairQuestion(Gen g, Random r, String[][] pairs, String relation, String relSol) {
        int i = r.nextInt(pairs.length);
        int dir = r.nextInt(2);
        String q = pairs[i][dir], ans = pairs[i][1 - dir];
        List<String> wrongs = new ArrayList<>();
        List<Integer> idx = new ArrayList<>();
        for (int k = 0; k < pairs.length; k++) if (k != i) idx.add(k);
        java.util.Collections.shuffle(idx, r);
        for (int k = 0; k < 3; k++) wrongs.add(pairs[idx.get(k)][r.nextInt(2)]);
        String text = "\"" + q + "\" sözcüğünün " + relation + " aşağıdakilerden hangisidir?";
        String sol = "\"" + q + "\" ile \"" + ans + "\" " + relSol + ".";
        return Qb.build(g, text, ans, wrongs, sol, r);
    }
}
