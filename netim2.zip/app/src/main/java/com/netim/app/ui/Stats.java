package com.netim.app.ui;

import android.content.Context;
import android.content.SharedPreferences;

/** Konu bazli basit istatistik. Yalnizca cihazda, SharedPreferences icinde tutulur. */
final class Stats {
    private final SharedPreferences sp;

    Stats(Context c) {
        sp = c.getSharedPreferences("netim_stats", Context.MODE_PRIVATE);
    }

    void record(String topic, boolean correct) {
        sp.edit().putInt(topic + "#n", asked(topic) + 1)
                .putInt(topic + "#c", right(topic) + (correct ? 1 : 0)).apply();
    }

    int asked(String topic) {
        return sp.getInt(topic + "#n", 0);
    }

    int right(String topic) {
        return sp.getInt(topic + "#c", 0);
    }

    void reset() {
        sp.edit().clear().apply();
    }
}
