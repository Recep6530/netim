package com.netim.app.engine;

/** Girilen sayilar icin adim adim cozum ureten cevrimdisi cozucu. */
public final class Solver {
    private Solver() {
    }

    public static final String[] TYPES = {"EBOB - EKOK", "Yüzde", "Birinci dereceden denklem", "Pisagor", "Ortalama", "Kesir toplama / çıkarma"};

    /** Her tur icin girdi etiketleri. */
    public static String[] labels(int type) {
        switch (type) {
            case 0: return new String[]{"1. sayı", "2. sayı"};
            case 1: return new String[]{"Sayı", "Yüzde (%)"};
            case 2: return new String[]{"a  (ax + b = c)", "b", "c"};
            case 3: return new String[]{"1. dik kenar", "2. dik kenar"};
            case 4: return new String[]{"Sayılar (aralarına boşluk koy)"};
            default: return new String[]{"1. kesrin payı", "1. kesrin paydası", "2. kesrin payı", "2. kesrin paydası", "İşlem (+ veya -)"};
        }
    }

    public static String solve(int type, String[] in) {
        try {
            switch (type) {
                case 0: return ebobEkok(num(in[0]), num(in[1]));
                case 1: return percent(num(in[0]), num(in[1]));
                case 2: return linear(num(in[0]), num(in[1]), num(in[2]));
                case 3: return pythag(num(in[0]), num(in[1]));
                case 4: return mean(in[0]);
                default: return fracs(num(in[0]), num(in[1]), num(in[2]), num(in[3]), in[4].trim());
            }
        } catch (NumberFormatException e) {
            return "Lütfen tüm kutulara geçerli sayı yaz.";
        } catch (IllegalArgumentException e) {
            return e.getMessage();
        }
    }

    private static long num(String s) {
        String t = s.trim();
        if (t.isEmpty()) throw new NumberFormatException();
        long v = Long.parseLong(t);
        if (Math.abs(v) > 1000000000L) throw new IllegalArgumentException("Sayılar en fazla 1 milyar olabilir.");
        return v;
    }

    static String ebobEkok(long a, long b) {
        if (a <= 0 || b <= 0) throw new IllegalArgumentException("EBOB-EKOK için pozitif sayılar yaz.");
        StringBuilder sb = new StringBuilder();
        sb.append(a).append(" = ").append(factor(a)).append("\n").append(b).append(" = ").append(factor(b)).append("\n\n");
        long g = Frac.gcd(a, b);
        long l = a / g * b;
        sb.append("EBOB: iki sayıda ortak olan asal çarpanların en küçük üslüleri çarpılır.\nEBOB = ").append(g).append("\n\n");
        sb.append("EKOK: tüm asal çarpanların en büyük üslüleri çarpılır. Kısa yol: (a × b) ÷ EBOB = ")
                .append(a).append(" × ").append(b).append(" ÷ ").append(g).append("\nEKOK = ").append(l);
        return sb.toString();
    }

    private static String factor(long n) {
        if (n == 1) return "1";
        StringBuilder sb = new StringBuilder();
        long x = n;
        for (long p = 2; p * p <= x; p++) {
            int c = 0;
            while (x % p == 0) {
                x /= p;
                c++;
            }
            if (c > 0) {
                if (sb.length() > 0) sb.append(" × ");
                sb.append(p);
                if (c > 1) sb.append(Qb.sup(c));
            }
        }
        if (x > 1) {
            if (sb.length() > 0) sb.append(" × ");
            sb.append(x);
        }
        return sb.toString();
    }

    static String percent(long x, long p) {
        long prod = x * p;
        String res = prod % 100 == 0 ? String.valueOf(prod / 100) : new Frac(prod, 100).toString() + " (" + prod / 100.0 + ")";
        return x + " sayısının yüzde " + p + " kadarı:\n\n" + x + " × " + p + " ÷ 100 = " + prod + " ÷ 100\n\nSonuç = " + res
                + "\n\nİpucu: Yüzde, 100 üzerinden orandır. %" + p + " = " + p + "/100.";
    }

    static String linear(long a, long b, long c) {
        if (a == 0) throw new IllegalArgumentException("a sıfır olamaz (denklem birinci dereceden olmalı).");
        long rhs = c - b;
        StringBuilder sb = new StringBuilder();
        sb.append(a).append("x ").append(b >= 0 ? "+ " : "− ").append(Math.abs(b)).append(" = ").append(c).append("\n\n");
        sb.append("1) Sabit terim karşıya geçer (işareti değişir):\n   ").append(a).append("x = ").append(c).append(b >= 0 ? " − " : " + ").append(Math.abs(b)).append(" = ").append(rhs).append("\n\n");
        Frac x = new Frac(rhs, a);
        if (a < 0) x = new Frac(-rhs, -a);
        sb.append("2) Her iki taraf ").append(a).append("'a bölünür:\n   x = ").append(rhs).append(" ÷ ").append(a).append(" = ").append(x).append("\n\n");
        sb.append("Kontrol: ").append(a).append(" × (").append(x).append(") ").append(b >= 0 ? "+ " : "− ").append(Math.abs(b)).append(" = ").append(c);
        return sb.toString();
    }

    static String pythag(long a, long b) {
        if (a <= 0 || b <= 0) throw new IllegalArgumentException("Kenarlar pozitif olmalı.");
        long s = a * a + b * b;
        long r = (long) Math.sqrt((double) s);
        while (r * r > s) r--;
        while ((r + 1) * (r + 1) <= s) r++;
        String res = r * r == s ? String.valueOf(r) : "√" + s + " ≈ " + Math.round(Math.sqrt((double) s) * 100) / 100.0;
        return "Dik üçgende (dik kenar)² + (dik kenar)² = (hipotenüs)²\n\n" + a + "² + " + b + "² = " + (a * a) + " + " + (b * b) + " = " + s
                + "\nHipotenüs = √" + s + "\n\nHipotenüs = " + res + (r * r == s ? "\n\n(Bu bir Pisagor üçlüsüdür.)" : "");
    }

    static String mean(String line) {
        String[] parts = line.trim().replace(",", " ").split("\\s+");
        if (parts.length < 2 || parts[0].isEmpty()) throw new IllegalArgumentException("En az iki sayı yaz.");
        long sum = 0;
        StringBuilder sb = new StringBuilder();
        for (String p : parts) {
            long v = num(p);
            sum += v;
            if (sb.length() > 0) sb.append(" + ");
            sb.append(v);
        }
        Frac m = new Frac(sum, parts.length);
        return "Aritmetik ortalama = sayıların toplamı ÷ sayı adedi\n\nToplam: " + sb + " = " + sum + "\nAdet: " + parts.length
                + "\n\nOrtalama = " + sum + " ÷ " + parts.length + " = " + m + (m.d != 1 ? " (" + (double) sum / parts.length + ")" : "");
    }

    static String fracs(long a, long b, long c, long d, String op) {
        if (b == 0 || d == 0) throw new IllegalArgumentException("Payda sıfır olamaz.");
        boolean plus = op.equals("+");
        if (!plus && !op.equals("-") && !op.equals("−")) throw new IllegalArgumentException("İşlem kutusuna + veya - yaz.");
        long den = b * d;
        long n1 = a * d, n2 = c * b;
        long num = plus ? n1 + n2 : n1 - n2;
        Frac r = new Frac(num, den);
        if (r.d < 0) r = new Frac(-r.n, -r.d);
        return a + "/" + b + (plus ? " + " : " − ") + c + "/" + d + "\n\n1) Paydalar eşitlenir (paydaların çarpımı: " + b + " × " + d + " = " + den + "):\n   ("
                + a + "×" + d + (plus ? " + " : " − ") + c + "×" + b + ") / " + den + "\n\n2) Paylar işlenir:\n   " + n1 + (plus ? " + " : " − ") + n2 + " = " + num
                + " → " + num + "/" + den + "\n\n3) Sadeleştirilir:\n   Sonuç = " + r;
    }
}
