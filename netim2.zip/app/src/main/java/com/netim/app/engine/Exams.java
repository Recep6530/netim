package com.netim.app.engine;

import java.util.Arrays;
import java.util.List;

/** Sinav tarzi kategorileri. Hepsi ozgun, uretilmis alistirmalardir; gercek sinav sorusu icermez. */
public final class Exams {
    public static final class Exam {
        public final String name;
        public final String info;
        public final List<String> subjects;

        Exam(String name, String info, String... subjects) {
            this.name = name;
            this.info = info;
            this.subjects = Arrays.asList(subjects);
        }
    }

    public static final List<Exam> ALL = Arrays.asList(
            new Exam("LGS tarzı", "8. sınıf düzeyi temel matematik ve Türkçe alıştırmaları", Engine.MAT, Engine.TUR),
            new Exam("TYT tarzı", "Temel matematik ve Türkçe alıştırmaları", Engine.MAT, Engine.TUR),
            new Exam("KPSS tarzı", "Genel yetenek: sayısal ve sözel alıştırmalar", Engine.MAT, Engine.TUR),
            new Exam("ALES tarzı", "Sayısal ve sözel mantık alıştırmaları", Engine.MAT, Engine.TUR),
            new Exam("DGS tarzı", "Sayısal ve sözel alıştırmalar", Engine.MAT, Engine.TUR),
            new Exam("EKPSS tarzı", "Genel yetenek: sayısal ve sözel alıştırmalar", Engine.MAT, Engine.TUR),
            new Exam("Genel", "Tüm konular", Engine.MAT, Engine.TUR)
    );

    private Exams() {
    }

    public static Exam byName(String n) {
        for (Exam e : ALL) if (e.name.equals(n)) return e;
        return ALL.get(0);
    }
}
