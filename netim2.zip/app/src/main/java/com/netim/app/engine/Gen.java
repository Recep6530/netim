package com.netim.app.engine;

import java.util.Random;

/** Bir konu icin soru ureticisi. */
public interface Gen {
    String subject();

    String topic();

    Question make(Random r);
}
