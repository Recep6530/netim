package com.netim.app.ui;

import android.content.Context;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Ortak renkler ve kucuk gorunum yardimcilari. */
public final class Ui {
    private Ui() {
    }

    public static final int BG = 0xFF0A0E1A;
    public static final int SURFACE = 0xFF111829;
    public static final int CARD = 0xFF172138;
    public static final int LINE = 0xFF24304D;
    public static final int ACC = 0xFF22D3EE;
    public static final int ACC2 = 0xFF8B5CF6;
    public static final int TXT = 0xFFEAF0FF;
    public static final int MUT = 0xFF93A0BE;
    public static final int OK = 0xFF34D399;
    public static final int WARN = 0xFFF59E0B;
    public static final int BAD = 0xFFF87171;

    public static int dp(Context c, int v) {
        return Math.round(v * c.getResources().getDisplayMetrics().density);
    }

    public static GradientDrawable rr(Context c, int color, int radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(c, radiusDp));
        return g;
    }

    public static GradientDrawable rrStroke(Context c, int fill, int stroke, int radiusDp) {
        GradientDrawable g = rr(c, fill, radiusDp);
        g.setStroke(dp(c, 1), stroke);
        return g;
    }

    public static TextView tv(Context c, String s, int sp, int color, boolean bold) {
        TextView t = new TextView(c);
        t.setText(s);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    public static LinearLayout vbox(Context c) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }

    public static LinearLayout hbox(Context c) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.HORIZONTAL);
        return l;
    }

    public static LinearLayout.LayoutParams lp(Context c, int w, int h, int l, int t, int r, int b) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(w, h);
        p.setMargins(dp(c, l), dp(c, t), dp(c, r), dp(c, b));
        return p;
    }

    /** Yuvarlatilmis kart. Icine addView ile eklenir. */
    public static LinearLayout card(Context c) {
        LinearLayout l = vbox(c);
        l.setBackground(rrStroke(c, CARD, LINE, 16));
        int p = dp(c, 14);
        l.setPadding(p, p, p, p);
        return l;
    }

    public static void addCard(LinearLayout parent, View card) {
        parent.addView(card, lp(parent.getContext(), LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT, 0, 0, 0, 10));
    }

    public static TextView button(Context c, String label, boolean primary, View.OnClickListener l) {
        TextView b = tv(c, label, 14, primary ? BG : ACC, true);
        b.setGravity(Gravity.CENTER);
        b.setBackground(primary ? rr(c, ACC, 12) : rrStroke(c, SURFACE, ACC, 12));
        b.setPadding(dp(c, 14), dp(c, 12), dp(c, 14), dp(c, 12));
        b.setOnClickListener(l);
        return b;
    }

    public static void addButton(LinearLayout parent, TextView button) {
        parent.addView(button, lp(parent.getContext(), LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT, 0, 8, 0, 0));
    }

    /** Filtre cipi. */
    public static TextView chip(Context c, String label, boolean selected, View.OnClickListener l) {
        TextView b = tv(c, label, 12, selected ? BG : MUT, true);
        b.setGravity(Gravity.CENTER);
        b.setBackground(selected ? rr(c, ACC, 16) : rrStroke(c, SURFACE, LINE, 16));
        b.setPadding(dp(c, 12), dp(c, 6), dp(c, 12), dp(c, 6));
        b.setOnClickListener(l);
        return b;
    }
}
