package com.netim.app.engine;

/** Sade kesir yardimcisi. */
final class Frac {
    final long n;
    final long d;

    Frac(long n, long d) {
        long g = gcd(Math.abs(n), Math.abs(d));
        if (g == 0) g = 1;
        this.n = n / g;
        this.d = d / g;
    }

    static long gcd(long a, long b) {
        while (b != 0) {
            long t = a % b;
            a = b;
            b = t;
        }
        return a;
    }

    boolean sameValue(Frac o) {
        return n * o.d == o.n * d;
    }

    @Override
    public String toString() {
        return d == 1 ? String.valueOf(n) : n + "/" + d;
    }
}
