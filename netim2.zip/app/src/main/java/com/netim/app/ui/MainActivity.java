package com.netim.app.ui;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowInsets;
import android.text.InputType;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import com.netim.app.engine.Engine;
import com.netim.app.engine.Exams;
import com.netim.app.engine.Notes;
import com.netim.app.engine.Solver;
import com.netim.app.engine.Gen;
import com.netim.app.engine.Question;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class MainActivity extends Activity {
    private static final int MP = ViewGroup.LayoutParams.MATCH_PARENT;
    private static final int WC = ViewGroup.LayoutParams.WRAP_CONTENT;

    private final Random rnd = new Random();
    private Stats stats;
    private LinearLayout content;
    private int tab = 0;

    // Calisma durumu
    private String exam = Exams.ALL.get(0).name;
    private String subject = Engine.MAT;
    private String topic = null; // null = karisik
    // Deneme durumu
    private List<Question> testQs;
    private int testIdx, testScore;
    private boolean testRunning;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        stats = new Stats(this);
        LinearLayout root = Ui.vbox(this);
        root.setBackgroundColor(Ui.BG);
        content = Ui.vbox(this);
        root.addView(content, new LinearLayout.LayoutParams(MP, 0, 1f));

        LinearLayout bar = Ui.hbox(this);
        bar.setBackgroundColor(Ui.SURFACE);
        final String[] names = {"Çalış", "Deneme", "Çöz", "İstatistik", "Hakkında"};
        for (int i = 0; i < names.length; i++) {
            final int idx = i;
            TextView t = Ui.tv(this, names[i], 12, Ui.TXT, true);
            t.setGravity(android.view.Gravity.CENTER);
            t.setPadding(0, Ui.dp(this, 14), 0, Ui.dp(this, 14));
            t.setOnClickListener(v -> {
                tab = idx;
                refreshBar(bar);
                show();
            });
            bar.addView(t, new LinearLayout.LayoutParams(0, WC, 1f));
        }
        root.addView(bar, new LinearLayout.LayoutParams(MP, WC));
        refreshBar(bar);
        setContentView(root);

        root.setOnApplyWindowInsetsListener((v, ins) -> {
            int top, bottom, left, right;
            if (Build.VERSION.SDK_INT >= 30) {
                android.graphics.Insets s = ins.getInsets(WindowInsets.Type.systemBars() | WindowInsets.Type.displayCutout());
                top = s.top;
                bottom = s.bottom;
                left = s.left;
                right = s.right;
            } else {
                top = ins.getSystemWindowInsetTop();
                bottom = ins.getSystemWindowInsetBottom();
                left = ins.getSystemWindowInsetLeft();
                right = ins.getSystemWindowInsetRight();
            }
            v.setPadding(left, top, right, bottom);
            return ins;
        });
        show();
    }

    private void refreshBar(LinearLayout bar) {
        for (int i = 0; i < bar.getChildCount(); i++) {
            ((TextView) bar.getChildAt(i)).setTextColor(i == tab ? Ui.ACC : Ui.MUT);
        }
    }

    private void show() {
        content.removeAllViews();
        if (tab == 0) showPractice();
        else if (tab == 1) showTest();
        else if (tab == 2) showSolver();
        else if (tab == 3) showStats();
        else showAbout();
    }

    private ScrollView scroller(LinearLayout inner) {
        ScrollView sv = new ScrollView(this);
        int p = Ui.dp(this, 16);
        inner.setPadding(p, p, p, p);
        sv.addView(inner, new ViewGroup.LayoutParams(MP, WC));
        content.addView(sv, new LinearLayout.LayoutParams(MP, MP));
        return sv;
    }

    private List<Gen> gens() {
        List<Gen> all = Engine.bySubject(subject);
        if (topic == null) return all;
        List<Gen> one = new ArrayList<>();
        for (Gen g : all) if (g.topic().equals(topic)) one.add(g);
        return one.isEmpty() ? all : one;
    }

    private void chips(LinearLayout parent, List<String> labels, String selected, boolean allowNone, ChipListener l) {
        HorizontalScrollView hs = new HorizontalScrollView(this);
        hs.setHorizontalScrollBarEnabled(false);
        LinearLayout row = Ui.hbox(this);
        if (allowNone) {
            row.addView(Ui.chip(this, "Karışık", selected == null, v -> l.pick(null)), Ui.lp(this, WC, WC, 0, 0, 6, 0));
        }
        for (String s : labels) {
            final String lab = s;
            row.addView(Ui.chip(this, s, s.equals(selected), v -> l.pick(lab)), Ui.lp(this, WC, WC, 0, 0, 6, 0));
        }
        hs.addView(row);
        parent.addView(hs, Ui.lp(this, MP, WC, 0, 0, 0, 8));
    }

    private interface ChipListener {
        void pick(String s);
    }

    // ---------- Calis ----------
    private Question cur;
    private boolean answered;

    private void showPractice() {
        LinearLayout box = Ui.vbox(this);
        scroller(box);
        box.addView(Ui.tv(this, "Çalış", 22, Ui.TXT, true));
        box.addView(Ui.tv(this, "Sorular her seferinde cihazında yeniden üretilir.", 12, Ui.MUT, false), Ui.lp(this, MP, WC, 0, 2, 0, 10));
        List<String> examNames = new ArrayList<>();
        for (Exams.Exam e : Exams.ALL) examNames.add(e.name);
        chips(box, examNames, exam, false, s -> {
            exam = s;
            if (!Exams.byName(s).subjects.contains(subject)) subject = Exams.byName(s).subjects.get(0);
            topic = null;
            cur = null;
            show();
        });
        box.addView(Ui.tv(this, Exams.byName(exam).info + ". Gerçek sınav sorusu değildir; özgün alıştırmalardır.", 11, Ui.MUT, false), Ui.lp(this, MP, WC, 0, 0, 0, 8));
        chips(box, Exams.byName(exam).subjects, subject, false, s -> {
            subject = s;
            topic = null;
            cur = null;
            show();
        });
        List<String> topics = new ArrayList<>();
        for (Gen g : Engine.bySubject(subject)) topics.add(g.topic());
        chips(box, topics, topic, true, s -> {
            topic = s;
            cur = null;
            show();
        });
        if (cur == null) {
            List<Gen> gl = gens();
            cur = Engine.next(gl.get(rnd.nextInt(gl.size())), rnd);
            answered = false;
        }
        if (topic != null) {
            Ui.addButton(box, Ui.button(this, "Konu anlatımı: " + topic, false, v ->
                    new AlertDialog.Builder(this).setTitle(topic).setMessage(Notes.get(topic)).setPositiveButton("Tamam", null).show()));
        }
        renderQuestion(box, cur, 0, 0);
    }

    private void renderQuestion(LinearLayout box, Question q, int number, int total) {
        LinearLayout card = Ui.card(this);
        String head = q.subject + " · " + q.topic + (total > 0 ? "   (" + number + "/" + total + ")" : "");
        card.addView(Ui.tv(this, head, 11, Ui.ACC, true));
        card.addView(Ui.tv(this, q.text, 17, Ui.TXT, true), Ui.lp(this, MP, WC, 0, 8, 0, 10));
        final TextView[] optViews = new TextView[q.options.length];
        final TextView feedback = Ui.tv(this, "", 13, Ui.TXT, false);
        feedback.setVisibility(View.GONE);
        final TextView next = Ui.button(this, "Sonraki soru", true, v -> onNext());
        next.setVisibility(View.GONE);
        for (int i = 0; i < q.options.length; i++) {
            final int idx = i;
            char letter = (char) ('A' + i);
            TextView o = Ui.tv(this, letter + ")  " + q.options[i], 15, Ui.TXT, false);
            o.setBackground(Ui.rrStroke(this, Ui.SURFACE, Ui.LINE, 12));
            o.setPadding(Ui.dp(this, 12), Ui.dp(this, 12), Ui.dp(this, 12), Ui.dp(this, 12));
            optViews[i] = o;
            o.setOnClickListener(v -> {
                if (isAnswered()) return;
                markAnswered();
                boolean ok = idx == q.correct;
                stats.record(q.topic, ok);
                if (testRunning && tab == 1) {
                    if (ok) testScore++;
                } 
                for (int k = 0; k < optViews.length; k++) {
                    if (k == q.correct) optViews[k].setBackground(Ui.rrStroke(this, 0x3334D399, Ui.OK, 12));
                    else if (k == idx) optViews[k].setBackground(Ui.rrStroke(this, 0x33F87171, Ui.BAD, 12));
                }
                feedback.setText((ok ? "Doğru! " : "Yanlış. Doğru cevap: " + (char) ('A' + q.correct) + ") ") + "\n\nÇözüm: " + q.solution);
                feedback.setTextColor(ok ? Ui.OK : Ui.TXT);
                feedback.setVisibility(View.VISIBLE);
                next.setVisibility(View.VISIBLE);
            });
            card.addView(o, Ui.lp(this, MP, WC, 0, 0, 0, 8));
        }
        card.addView(feedback, Ui.lp(this, MP, WC, 0, 6, 0, 4));
        card.addView(next);
        Ui.addCard(box, card);
    }

    private boolean isAnswered() {
        return answered;
    }

    private void markAnswered() {
        answered = true;
    }

    private void onNext() {
        if (tab == 0) {
            cur = null;
            show();
        } else {
            testIdx++;
            show();
        }
    }

    // ---------- Deneme ----------
    private static final int TEST_SIZE = 10;

    private void showTest() {
        LinearLayout box = Ui.vbox(this);
        scroller(box);
        box.addView(Ui.tv(this, "Deneme", 22, Ui.TXT, true));
        box.addView(Ui.tv(this, "Seçtiğin dersten 10 soruluk kısa alıştırma. Resmî bir deneme sınavı değildir.", 12, Ui.MUT, false), Ui.lp(this, MP, WC, 0, 2, 0, 10));
        if (!testRunning) {
            chips(box, Exams.byName(exam).subjects, subject, false, s -> {
                subject = s;
                show();
            });
            LinearLayout card = Ui.card(this);
            card.addView(Ui.tv(this, exam + " · " + subject + " · " + TEST_SIZE + " soru", 16, Ui.TXT, true));
            card.addView(Ui.tv(this, "Konular karışık gelir. Her sorudan sonra çözümü görürsün.", 13, Ui.MUT, false), Ui.lp(this, MP, WC, 0, 4, 0, 4));
            Ui.addButton(card, Ui.button(this, "Başla", true, v -> {
                List<Gen> gl = Engine.bySubject(subject);
                testQs = new ArrayList<>();
                for (int i = 0; i < TEST_SIZE; i++) testQs.add(Engine.next(gl.get(rnd.nextInt(gl.size())), rnd));
                testIdx = 0;
                testScore = 0;
                testRunning = true;
                answered = false;
                show();
            }));
            Ui.addCard(box, card);
            return;
        }
        if (testIdx >= testQs.size()) {
            LinearLayout card = Ui.card(this);
            card.addView(Ui.tv(this, "Bitti!", 20, Ui.OK, true));
            card.addView(Ui.tv(this, testScore + " / " + testQs.size() + " doğru", 18, Ui.TXT, true), Ui.lp(this, MP, WC, 0, 6, 0, 4));
            card.addView(Ui.tv(this, "Yanlış yaptığın konuları İstatistik sekmesinden görebilir, Çalış sekmesinde tekrar edebilirsin.", 13, Ui.MUT, false));
            Ui.addButton(card, Ui.button(this, "Yeni deneme", true, v -> {
                testRunning = false;
                show();
            }));
            Ui.addCard(box, card);
            return;
        }
        answered = false;
        renderQuestion(box, testQs.get(testIdx), testIdx + 1, testQs.size());
    }

    // ---------- Coz ----------
    private int solveType = 0;
    private String solveOut = "";

    private void showSolver() {
        LinearLayout box = Ui.vbox(this);
        scroller(box);
        box.addView(Ui.tv(this, "Soru çöz", 22, Ui.TXT, true));
        box.addView(Ui.tv(this, "Soru tipini seç, sayıları gir; adım adım çözümü gör. İnternet gerekmez. Her soru tipi desteklenmez.", 12, Ui.MUT, false), Ui.lp(this, MP, WC, 0, 2, 0, 10));
        List<String> types = new ArrayList<>();
        for (String t : Solver.TYPES) types.add(t);
        chips(box, types, Solver.TYPES[solveType], false, s -> {
            solveType = types.indexOf(s);
            solveOut = "";
            show();
        });
        LinearLayout card = Ui.card(this);
        String[] labels = Solver.labels(solveType);
        final EditText[] ed = new EditText[labels.length];
        for (int i = 0; i < labels.length; i++) {
            card.addView(Ui.tv(this, labels[i], 12, Ui.MUT, false), Ui.lp(this, MP, WC, 0, 6, 0, 2));
            EditText e = new EditText(this);
            e.setTextColor(Ui.TXT);
            e.setHintTextColor(Ui.MUT);
            e.setBackground(Ui.rrStroke(this, Ui.SURFACE, Ui.LINE, 10));
            e.setPadding(Ui.dp(this, 10), Ui.dp(this, 8), Ui.dp(this, 10), Ui.dp(this, 8));
            boolean text = solveType == 4 || (solveType == 5 && i == 4);
            e.setInputType(text ? InputType.TYPE_CLASS_TEXT : (InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_SIGNED));
            ed[i] = e;
            card.addView(e, new LinearLayout.LayoutParams(MP, WC));
        }
        final TextView out = Ui.tv(this, solveOut, 14, Ui.TXT, false);
        Ui.addButton(card, Ui.button(this, "Çöz", true, v -> {
            String[] in = new String[ed.length];
            for (int i = 0; i < ed.length; i++) in[i] = ed[i].getText().toString();
            solveOut = Solver.solve(solveType, in);
            out.setText(solveOut);
        }));
        card.addView(out, Ui.lp(this, MP, WC, 0, 12, 0, 0));
        Ui.addCard(box, card);
    }

    // ---------- Istatistik ----------
    private void showStats() {
        LinearLayout box = Ui.vbox(this);
        scroller(box);
        box.addView(Ui.tv(this, "İstatistik", 22, Ui.TXT, true), Ui.lp(this, MP, WC, 0, 0, 0, 10));
        int tn = 0, tc = 0;
        for (Gen g : Engine.all()) {
            tn += stats.asked(g.topic());
            tc += stats.right(g.topic());
        }
        LinearLayout sum = Ui.card(this);
        sum.addView(Ui.tv(this, tn == 0 ? "Henüz soru çözmedin." : tc + " / " + tn + " doğru  (%" + (100 * tc / tn) + ")", 16, Ui.TXT, true));
        Ui.addCard(box, sum);
        for (String s : Engine.subjects()) {
            LinearLayout card = Ui.card(this);
            card.addView(Ui.tv(this, s, 15, Ui.ACC, true), Ui.lp(this, MP, WC, 0, 0, 0, 6));
            for (Gen g : Engine.bySubject(s)) {
                int n = stats.asked(g.topic()), c = stats.right(g.topic());
                String line = g.topic() + ":  " + (n == 0 ? "-" : c + "/" + n + "  (%" + (100 * c / n) + ")");
                int col = n == 0 ? Ui.MUT : (100 * c / n >= 70 ? Ui.OK : Ui.WARN);
                card.addView(Ui.tv(this, line, 13, col, false), Ui.lp(this, MP, WC, 0, 2, 0, 2));
            }
            Ui.addCard(box, card);
        }
        Ui.addButton(box, Ui.button(this, "İstatistikleri sıfırla", false, v ->
                new AlertDialog.Builder(this).setMessage("Tüm istatistikler silinsin mi?")
                        .setPositiveButton("Sil", (d, w) -> {
                            stats.reset();
                            show();
                        }).setNegativeButton("Vazgeç", null).show()));
    }

    // ---------- Hakkinda ----------
    private void showAbout() {
        LinearLayout box = Ui.vbox(this);
        scroller(box);
        box.addView(Ui.tv(this, "Hakkında", 22, Ui.TXT, true), Ui.lp(this, MP, WC, 0, 0, 0, 10));
        LinearLayout card = Ui.card(this);
        String[] lines = {
                "Netim, internet gerektirmeden çalışan bir alıştırma uygulamasıdır. Sorular cihazında, kurallara ve hesaplamalara göre otomatik üretilir.",
                "Resmî bir kurum veya sınav hizmeti değildir; Millî Eğitim Bakanlığı, ÖSYM ve benzeri kurumlarla bağlantısı yoktur. LGS, TYT, KPSS gibi adlar yalnızca alıştırmanın düzeyini ve tarzını belirtir. Gerçek sınav sorularını içermez; tüm sorular cihazda özgün olarak üretilir.",
                "Başarı veya sınav sonucu garanti etmez; yalnızca pratik yapmana yardım eder. Soru ve çözümlerde hata olabilir, şüphe duyduğunda öğretmenine veya ders kitabına başvur.",
                "Kişisel veri toplamaz. İstatistiklerin yalnızca bu cihazda saklanır, hiçbir yere gönderilmez. Uygulamanın internet izni yoktur."
        };
        for (String s : lines) card.addView(Ui.tv(this, s, 13, Ui.TXT, false), Ui.lp(this, MP, WC, 0, 0, 0, 10));
        card.addView(Ui.tv(this, "Sürüm 0.2 (kişisel test sürümü)", 12, Ui.MUT, false));
        Ui.addCard(box, card);
    }
}
