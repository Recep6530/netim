package com.netim.app.engine;

/** Uretilmis bir soru: metin, 4 sik, dogru sik ve adim adim cozum. */
public final class Question {
    public final String subject;
    public final String topic;
    public final String text;
    public final String[] options;
    public final int correct;
    public final String solution;

    public Question(String subject, String topic, String text, String[] options, int correct, String solution) {
        this.subject = subject;
        this.topic = topic;
        this.text = text;
        this.options = options;
        this.correct = correct;
        this.solution = solution;
    }
}
