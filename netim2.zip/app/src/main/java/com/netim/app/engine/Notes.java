package com.netim.app.engine;

import java.util.HashMap;
import java.util.Map;

/** Konu anlatimlari (kisa, ozgun yazilmis). */
public final class Notes {
    private static final Map<String, String> M = new HashMap<>();

    private Notes() {
    }

    public static String get(String topic) {
        String s = M.get(topic);
        return s != null ? s : "Bu konu için anlatım yakında eklenecek.";
    }

    static {
        M.put("İşlem önceliği", "Sıra: 1) parantez içi, 2) üs ve kök, 3) çarpma ve bölme (soldan sağa), 4) toplama ve çıkarma (soldan sağa).\nÖrnek: 3 + 4 × 2 = 3 + 8 = 11 (önce çarpma).\nSık hata: soldan sağa doğrudan işlem yapmak.");
        M.put("EBOB - EKOK", "Sayıları asal çarpanlarına ayır.\nEBOB: ortak asal çarpanların en küçük üslüleri çarpılır.\nEKOK: bütün asal çarpanların en büyük üslüleri çarpılır.\nKısa yol: EBOB × EKOK = iki sayının çarpımı.\nEBOB 'bölme, paylaştırma' (en büyük ortak bölen), EKOK 'aynı anda buluşma' sorularında çıkar.");
        M.put("Kesirlerle işlemler", "Toplama-çıkarma: paydalar eşitlenir, paylar işlenir.\na/b + c/d = (a×d + c×b) / (b×d)\nSonunda sonuç sadeleştirilir (pay ve paydayı ortak bölenlerine böl).\nÇarpma: pay×pay / payda×payda. Bölme: ikinci kesri ters çevirip çarp.");
        M.put("Yüzde problemleri", "Yüzde p = p/100.\nBir sayının %p'si = sayı × p ÷ 100.\nİndirim: yeni fiyat = fiyat − indirim miktarı.\nİpucu: %10 için sayıyı 10'a böl, %50 için ikiye böl, %25 için dörde böl.");
        M.put("Oran - orantı", "Doğru orantı: biri artınca diğeri aynı oranda artar. Önce birim değeri bul (1 kg kaç TL), sonra istenen miktarla çarp.\nÇapraz çarpım: a/b = c/d ise a×d = b×c.\nTers orantıda (işçi sayısı-gün gibi) çarpım sabittir.");
        M.put("Birinci dereceden denklem", "Amaç x'i yalnız bırakmaktır.\n1) Sabit terimi karşıya at (işareti değişir).\n2) x'in katsayısına böl.\n3) Sonucu denklemde yerine koyup kontrol et.\nÖrnek: 3x + 5 = 20 → 3x = 15 → x = 5.");
        M.put("Üslü sayılar", "Tabanlar aynıysa: çarparken üsler toplanır (aᵐ·aⁿ=aᵐ⁺ⁿ), bölerken çıkarılır (aᵐ÷aⁿ=aᵐ⁻ⁿ).\nÜssün üssü: (aᵐ)ⁿ = aᵐ·ⁿ.\nSık hata: 2³ × 2² için üsleri çarpmak. Doğrusu 2⁵ = 32.");
        M.put("Karekök", "√(a²) = a (a pozitifken).\n√a × √b = √(a×b).\nTam kareleri ezberle: 1, 4, 9, 16, 25, 36, 49, 64, 81, 100, 121, 144, 169, 196, 225.\nSık hata: √(a+b) ≠ √a + √b.");
        M.put("Aritmetik ortalama", "Ortalama = toplam ÷ adet.\nOrtalama biliniyorsa toplam = ortalama × adet.\nEksik sayıyı bulmak için: toplam − bilinenlerin toplamı.");
        M.put("Pisagor teoremi", "Dik üçgende a² + b² = c² (c hipotenüs, dik açının karşısındaki en uzun kenar).\nHazır üçlüler: (3,4,5), (5,12,13), (8,15,17), (7,24,25) ve katları.\nBir kenar eksikse karelerin farkını al, sonra karekök.");
        M.put("Alan ve çevre", "Dikdörtgen: alan = a×b, çevre = 2(a+b).\nKare: alan = a², çevre = 4a.\nÜçgen: alan = taban × yükseklik ÷ 2.\nDaire: alan = πr², çevre = 2πr.\nBirimlere dikkat: alan cm², çevre cm.");
        M.put("Hız - yol - zaman", "Yol = hız × zaman. Hız = yol ÷ zaman. Zaman = yol ÷ hız.\nİki araç birbirine doğru gidiyorsa hızlar toplanır, aynı yöne gidiyorsa hızlar çıkarılır.\nBirimleri aynı yap (km ve saat).");
        M.put("İş problemleri", "Bir işi x günde bitiren, bir günde işin 1/x'ini yapar.\nİki kişi birlikte: 1/x + 1/y = (x+y)/(x·y), süre = x·y ÷ (x+y).\nÖrnek: 6 ve 3 gün → birlikte 6×3÷9 = 2 gün.");
        M.put("Kâr - zarar", "Satış = alış + kâr. Kâr oranı alış fiyatına göre hesaplanır.\n%p kârla satış = alış × (100+p) ÷ 100.\nAlışı bulmak için satışı (100+p)'ye böl, 100 ile çarp.");
        M.put("Asal sayılar", "Asal sayı: yalnızca 1'e ve kendisine bölünen, 1'den büyük sayı. 2 tek çift asaldır.\nKontrol: sayının kareköküne kadar olan asallara bölünüp bölünmediğine bak.\n100'e kadar 25 asal vardır.");
        M.put("Sayı örüntüleri", "Aritmetik dizide ardışık terimler arasındaki fark sabittir (ortak fark d).\nn. terim = ilk terim + (n−1) × d.\nÖnce farkı bul, sonra formülü uygula.");
        M.put("Olasılık", "Olasılık = istenen durum sayısı ÷ tüm durum sayısı. Sonuç 0 ile 1 arasındadır.\nTorbadan çekme: toplam top sayısı paydaya, istenen renk paya yazılır.\nOlmayan olay 0, kesin olay 1'dir.");
        M.put("Hece sayısı", "Türkçede her hecede yalnızca bir ünlü (sesli) harf bulunur: a, e, ı, i, o, ö, u, ü.\nBir sözcüğün hece sayısı = ünlü sayısı.\nÖrnek: ka-lem → 2 hece.");
        M.put("Sessiz harf sayısı", "Ünlüler: a e ı i o ö u ü. Diğer harfler sessizdir (ünsüz).\nSessiz harf sayısı = harf sayısı − ünlü sayısı.");
        M.put("Zıt anlamlı sözcükler", "Zıt (karşıt) anlamlı sözcükler birbirinin tersini anlatır: sıcak - soğuk.\nSoruda hem kelimenin anlamına hem türüne bak (isim-isim, fiil-fiil).");
        M.put("Eş anlamlı sözcükler", "Eş anlamlı sözcükler aynı kavramı anlatır: cevap - yanıt.\nTam eş anlamlı çok azdır; cümleye uyup uymadığına da bak.");
        M.put("Ünlü uyumu (çoğul eki)", "Kalın ünlü (a, ı, o, u) ile biten son hece → -lar: kitap-lar.\nİnce ünlü (e, i, ö, ü) → -ler: ev-ler.\nSon hecedeki ünlüye bakılır.");
        M.put("Alfabetik sıralama", "Türk alfabesi (29 harf): a b c ç d e f g ğ h ı i j k l m n o ö p r s ş t u ü v y z.\nÖnce ilk harfe bakılır; eşitse ikinci harfe geçilir.\nÇ, Ğ, İ, Ö, Ş, Ü kendi sıralarındadır (ç, c'den sonra).");
    }
}
