package com.netim.app.engine;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Random;

/** Soru/sik kurma yardimcilari. */
final class Qb {
    private Qb() {
    }

    /** Dogru cevap + yanlis siklar havuzundan 4 siklik soru kurar. */
    static Question build(Gen g, String text, String correct, List<String> wrongPool, String solution, Random r) {
        LinkedHashSet<String> set = new LinkedHashSet<>();
        for (String w : wrongPool) {
            if (w != null && !w.equals(correct)) set.add(w);
        }
        if (set.size() < 3) throw new IllegalStateException("Yeterli yanlis sik yok: " + text);
        List<String> wrongs = new ArrayList<>(set).subList(0, 3);
        List<String> all = new ArrayList<>(wrongs);
        int pos = r.nextInt(4);
        all.add(pos, correct);
        return new Question(g.subject(), g.topic(), text, all.toArray(new String[0]), pos, solution);
    }

    /** Sayisal havuz: once verilen akilli yanlislar, sonra cevaba yakin degerler. */
    static List<String> numericPool(long min, long ans, long... cands) {
        LinkedHashSet<Long> set = new LinkedHashSet<>();
        for (long c : cands) {
            if (c != ans && c >= min) set.add(c);
        }
        for (long k = 1; set.size() < 8 && k < 100; k++) {
            if (ans + k >= min && ans + k != ans) set.add(ans + k);
            if (ans - k >= min) set.add(ans - k);
        }
        List<String> out = new ArrayList<>();
        for (Long v : set) out.add(String.valueOf(v));
        return out;
    }

    static List<String> fracPool(Frac ans, Frac... cands) {
        LinkedHashSet<String> set = new LinkedHashSet<>();
        for (Frac c : cands) {
            if (c != null && c.d != 0 && c.n > 0 && !c.sameValue(ans)) set.add(c.toString());
        }
        for (long k = 1; set.size() < 8 && k < 50; k++) {
            Frac a = new Frac(ans.n + k, ans.d);
            if (!a.sameValue(ans)) set.add(a.toString());
            Frac b = new Frac(ans.n, ans.d + k);
            if (!b.sameValue(ans)) set.add(b.toString());
        }
        return new ArrayList<>(set);
    }

    static String sup(int n) {
        String digits = "⁰¹²³⁴⁵⁶⁷⁸⁹";
        StringBuilder sb = new StringBuilder();
        for (char c : String.valueOf(n).toCharArray()) sb.append(digits.charAt(c - '0'));
        return sb.toString();
    }

    static long pow(long a, int e) {
        long r = 1;
        for (int i = 0; i < e; i++) r *= a;
        return r;
    }

    static <T> T pick(Random r, T[] arr) {
        return arr[r.nextInt(arr.length)];
    }

    static int range(Random r, int lo, int hi) {
        return lo + r.nextInt(hi - lo + 1);
    }

    static void check(boolean ok, String msg) {
        if (!ok) throw new IllegalStateException("Dogrulama hatasi: " + msg);
    }
}
